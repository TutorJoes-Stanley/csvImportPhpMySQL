<?php
// Load the database configuration file
include_once 'config.php';

if(isset($_POST['submit'])){
    
    // Allowed mime types
    $csvMimes = array('application/vnd.ms-excel');
    
    // Validate whether selected file is a CSV file
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)){
        
        // If the file is uploaded
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            // Open uploaded CSV file with read-only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            
            // Skip the first line
            fgetcsv($csvFile);
            
            // Parse data from CSV file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE){
                // Get row data

$NAME=$line[0];
$AGE=$line[1];
$CITY=$line[2];
$CONTACT=$line[3];

			
				
                
                // Check whether member already exists in the database with the same email
               $prevQuery = "SELECT ID FROM users WHERE CONTACT = '".$line[3]."'";
                $prevResult = $con->query($prevQuery);
                
                if($prevResult->num_rows > 0){
                    // Update member data in the database
					$s="UPDATE users SET NAME = '".$NAME."', CITY = '".$CITY."',CONTACT = '".$CONTACT."',AGE = '".$AGE."'
					WHERE CONTACT = '".$CONTACT."'";
                    $con->query($s);
                }else{
                    // Insert member data in the database
					$s="INSERT INTO users (NAME,AGE,CITY,CONTACT
) VALUES ('{$NAME}','{$AGE}','{$CITY}','{$CONTACT}')";
                    $con->query($s);
                }
            }
            
            // Close opened CSV file
            fclose($csvFile);
            
            $qstring = '?status=succ';
        }else{
            $qstring = '?status=err';
        }
    }else{
        $qstring = '?status=invalid_file';
    }
}
// Redirect to the listing page
echo "<script>window.open('index.php{$qstring}','_self')</script>";