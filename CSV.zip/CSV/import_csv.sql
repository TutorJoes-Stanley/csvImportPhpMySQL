-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 04, 2020 at 01:45 PM
-- Server version: 8.0.17
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `import_csv`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(10) UNSIGNED NOT NULL,
  `NAME` varchar(45) NOT NULL,
  `CITY` varchar(45) NOT NULL,
  `AGE` int(10) UNSIGNED NOT NULL,
  `CONTACT` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `NAME`, `CITY`, `AGE`, `CONTACT`) VALUES
(1, 'JENNIFER T', 'Chennai', 18, '9856859585'),
(2, 'CHOUDRI PRAKASH.S', 'Coimbatore', 17, '9856875369'),
(3, 'PRIYANKA.S', 'Madurai', 22, '9856891153'),
(4, 'LINGESH KUMAR.M.K', 'Tiruchirappalli', 21, '9856906937'),
(5, 'SANJAYKUMAR S', 'Tiruppur', 19, '9856922721'),
(6, 'ASHIK ELLAGHI.Y.H', 'Salem', 17, '9856938505'),
(7, 'KOWSALYA.K', 'Erode', 22, '9856954289'),
(8, 'KISHORKUMAR Y', 'Tirunelveli', 21, '9856970073'),
(9, 'MAHALAKSHMI.M', 'Vellore', 22, '9856985857'),
(10, 'SAKTHI DEVI T K', 'Thoothukkudi', 17, '9857001641'),
(11, 'KRISHNAVENI P', 'Dindigul', 18, '9857017425'),
(12, 'RIFAKATH MIAN K', 'Thanjavur', 19, '9857033209'),
(13, 'SWATHY.S', 'Ranipet', 18, '9857048993'),
(14, 'PRABAVATHI S', 'Sivakasi', 20, '9857064777'),
(15, 'SHESHAGIRI.E', 'Karur', 19, '9857080561'),
(16, 'REVANTH R', 'Udhagamandalam', 17, '9857096345'),
(17, 'SUSHMITHA S', 'Hosur', 21, '9857112129'),
(18, 'CHRISTINA CATHERINE J.P', 'Nagercoil', 19, '9857127913'),
(19, 'THENDRAL E', 'Kancheepuram', 19, '9857143697'),
(20, 'GOWTHAM P', 'Kumarapalayam', 22, '9857159481'),
(21, 'JEEVANANDHINI T', 'Karaikkudi', 17, '9857175265'),
(22, 'KANNAN S', 'Neyveli', 20, '9857191049'),
(23, 'SASIKALA A', 'Cuddalore', 19, '9857206833'),
(24, 'ROBIN RASHAL Y', 'Kumbakonam', 19, '9857222617'),
(25, 'PRAKASH.N', 'Tiruvannamalai', 18, '9857238401'),
(26, 'PRIYADHARSINI.H', 'Pollachi', 18, '9857254185'),
(27, 'KARTHICK.R', 'Gudiyatham', 17, '9857269969'),
(28, 'DHARSHINI E', 'Pudukkottai', 17, '9857285753'),
(29, 'VISHNU PRIYA V', 'Vaniyambadi', 18, '9857301537'),
(30, 'PRAVEEN KUMAR.M', 'Ambur', 21, '9857317321'),
(31, 'SANTHOSH KUMAR M', 'Nagapattinam', 17, '9857333105'),
(32, 'AKILASWARAN A R', 'Chennai', 17, '9857348889'),
(33, 'ARRIVAZHAGAN.K', 'Coimbatore', 21, '9857364673'),
(34, 'VISHNUVARDHAN S K', 'Madurai', 17, '9857380457'),
(35, 'HARIHARAN R', 'Tiruchirappalli', 18, '9857396241'),
(36, 'DASTHAGEER BEIG H', 'Tiruppur', 20, '9857412025'),
(37, 'PARAMESHWARI.S', 'Salem', 19, '9857427809'),
(38, 'JULIATE ROSY J', 'Erode', 22, '9857443593'),
(39, 'NANDHA KUMAR R', 'Tirunelveli', 22, '9857459377'),
(40, 'AJITHKUMAR S', 'Vellore', 22, '9857475161'),
(41, 'MALINI.M', 'Thoothukkudi', 21, '9857490945'),
(42, 'NANDHINI.S', 'Dindigul', 18, '9857506729'),
(43, 'NARAYANA RANGA.K', 'Thanjavur', 17, '9857522513'),
(44, 'DEEPAK KUMAR K', 'Ranipet', 21, '9857538297'),
(45, 'MAYIL ANANTHAN M', 'Sivakasi', 19, '9857554081'),
(46, 'SINDHUJA.J', 'Karur', 20, '9857569865'),
(47, 'NAGARAJ PANDIYAN.G', 'Udhagamandalam', 22, '9857585649'),
(48, 'PARTHIBAN R', 'Hosur', 21, '9857601433'),
(49, 'HARINI G', 'Nagercoil', 22, '9857617217'),
(50, 'AASHIQ ALI S', 'Tirunelveli', 17, '9931249577');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
