<?php
		$con=new mysqli("localhost","root","root","import_csv");
?>