<?php 
include "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Import CSV</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Import CSV In PHP & MySQL</h2>
    <form action="importData.php" method="post"  enctype="multipart/form-data">
	     <input type="file" name="file" />
         <button type="submit"  name="submit">IMPORT</button>
    </form>
    
    <?php
if(!empty($_GET['status'])){
	switch($_GET['status']){
		case 'succ':
			$statusMsg = 'Users data has been imported successfully.';
			break;
		case 'err':
			$statusMsg = 'Some problem occurred, please try again.';
			break;
		case 'invalid_file':
			$statusMsg = 'Please upload a valid CSV file.';
			break;
		default:
			$statusMsg = '';
    }
    echo "<h4>{$statusMsg}</h4>";
}
?>

    <table>
        <thead>
            <tr>
                <th>SNO</th>
                <th>NAME</th>
                <th>AGE</th>
                <th>CITY</th>
                <th>CONTACT</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Get member rows
        $result = $con->query("SELECT * FROM users");
        if($result->num_rows > 0){
			$i=0;
            while($row = $result->fetch_assoc()){
				$i++;
        ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $row['NAME']; ?></td>
                <td><?php echo $row['AGE']; ?></td>
                <td><?php echo $row['CITY']; ?></td>
                <td><?php echo $row['CONTACT']; ?></td>
            </tr>
        <?php } }else{ ?>
            <tr><td colspan="5">No Users found...</td></tr>
        <?php } ?>
        </tbody>
    </table>

</body>
</html>